#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *philosopherThread(void *argc) {
    int *argument = (int *)argc;
    int id = argument[0];
    printf("This is philosopher %d\n", id);
    free(argc); // Free the allocated memory when it is no longer needed
    pthread_exit(NULL);
}

void createPhilosophers(int nthreads) {
    pthread_t lines[nthreads];
    for (int i = 0; i < nthreads; i++) {
        int *target = (int *)malloc(1 * sizeof(int));
        target[0] = i; // index
        if (pthread_create(&lines[i], NULL, philosopherThread, (void *)target) != 0) {
            printf("Error in thread creation");
            return; // Return without a value since the function is void
        }
    }

    for (int i = 0; i < nthreads; i++) {
        pthread_join(lines[i], NULL);
    }
    printf("%d threads have been completed/joined successfully!\n", nthreads); // Corrected the variable name
}

int main(int argc, char **argv) {
    // number of threads/philosophers
    if (argc != 2) {
        printf("Usage: %s <number_of_threads>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);
    printf("Atul Assignment 7: # of threads = %d\n", n);
    createPhilosophers(n);
    return 0;
}
