#include <stdio.h>
#include <Windows.h>

struct sharedData {
    int n;
    int catalan[100];  // Adjust the size as needed
};

int main() {
    struct sharedData* sharedData;

    HANDLE hMapFile = OpenFileMappingW(FILE_MAP_READ, FALSE, L"Local\\CatalanMemory");

    if (hMapFile == NULL) {
        fprintf(stderr, "Could not open file mapping object: %lu\n", GetLastError());
        return 1;
    }

    sharedData = (struct sharedData*)MapViewOfFile(hMapFile, FILE_MAP_READ, 0, 0, sizeof(struct sharedData));
    if (sharedData == NULL) {
        fprintf(stderr, "Could not map view of file: %lu\n", GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    printf("Catalan Numbers:\n");
    for (int i = 0; i < sharedData->n; ++i) {
        printf("%d ", sharedData->catalan[i]);
    }
    printf("\n");
    int count=0;
    UnmapViewOfFile(sharedData);
    CloseHandle(hMapFile);

    return 0;
}