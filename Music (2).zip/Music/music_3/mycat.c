#include <stdio.h>
#include<unistd.h>
#include<

int main()
{
    
    int num;
    printf("Enter the integer: ");
    scanf("%d", &num);
    printf("Entered integer is: %d\n", num);
    return 0;
}
