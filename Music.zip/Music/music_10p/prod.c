#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include <Windows.h>

struct sharedData {
    int n;
    int catalanNumbers[100];  // Adjust the size as needed
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: producer.exe <number_of_catalan_numbers>\n");
        return 1;
    }

    int n = atoi(argv[1]);
    struct sharedData* sharedData;

    HANDLE hMapFile = CreateFileMappingW(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(struct sharedData),
        L"Local\\CatalanMemory");

    if (hMapFile == NULL) {
        fprintf(stderr, "Could not create file mapping object: %lu\n", GetLastError());
        return 1;
    }

    sharedData = (struct sharedData*)MapViewOfFile(hMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(struct sharedData));
    if (sharedData == NULL) {
        fprintf(stderr, "Could not map view of file: %lu\n", GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    sharedData->n = n;
    sharedData->catalanNumbers[0] = 1;

    for (int i = 1; i < n; ++i) {
        sharedData->catalanNumbers[i] = (sharedData->catalanNumbers[i - 1] * (2 * i * (2 * i - 1))) / ((i + 1) * i);
    }
    int timer=1000;
    while(timer){
        sleep(1);
        timer--;
    UnmapViewOfFile(sharedData);
    }
    CloseHandle(hMapFile);

    return 0;
}